package com.elsey.activity4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class VerifySchool extends AppCompatActivity {

    EditText etSchool1,etSchool2,etSchool3,etSchool4,etSchool5,etSchool6,etSchool7,etSchool8,etschoolVerify;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_school);
        etschoolVerify = findViewById(R.id.inSchoolName);

    }

    public void verify(View v){
        sp = getSharedPreferences("data1",MODE_PRIVATE);

    //    String school1SP =sp.getString("school1",null);
     //   String school2SP =sp.getString("school2",null);
      //  String school3SP =sp.getString("school3",null);
      //  String school4SP =sp.getString("school4",null);
       // String school5SP =sp.getString("school5",null);
        //String school6SP =sp.getString("school6",null);
        //String school7SP =sp.getString("school7",null);
        //String school8SP =sp.getString("school8",null);

        String verification = etschoolVerify.getText().toString();

        for (int i = 1; i<=8; i++){
            if (sp.getString("school"+i,null).equals(verification)){
                Toast.makeText(this,"school is competing in UAAP",Toast.LENGTH_LONG).show();
            } else{
                Toast.makeText(this,"school is not competeting in UAAP", Toast.LENGTH_LONG).show();
            }
        }
    }


}
