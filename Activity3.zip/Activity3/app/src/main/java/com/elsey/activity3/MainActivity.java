package com.elsey.activity3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = (Button) findViewById(R.id.button1);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openPortal();
            }
        });


    }

    @Override
    protected void onResume(){
        super.onResume();
        Intent i = new Intent(this,MyService.class);
        startService(i);
    }

    public void displayLog(View v){
        super.onResume();
        Intent i = new Intent(this,MyService.class);
        startService(i);
    }

    public void onClick(View v) {
        Intent myIntent = new Intent(MainActivity.this, Portals.class);
        startService(myIntent);
    }

    public void openPortal(){
        Intent intent = new Intent(this, Portals.class);
        startActivity(intent);
    }

}